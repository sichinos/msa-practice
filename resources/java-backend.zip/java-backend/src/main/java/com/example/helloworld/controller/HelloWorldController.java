package com.example.helloworld.controller;

import java.time.LocalDateTime;
import java.util.concurrent.TimeUnit;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

	@GetMapping("/hello")
	public String sendGreetings() {
		return "<html>\n" + "<body>\n" + "Hello World from Java Monolith.\n" + "<p>Message from Java Backend is  "
				+ getMessage() + "</p></body>\n" + "</html>";
	}

	private String getMessage() {
		return "今のJava Backend上日時は、" + LocalDateTime.now().toString();
	}

	@GetMapping("/api")
	public String api() {
		if ("error".equalsIgnoreCase(System.getenv("VERSION")))
			throw new RuntimeException();

		if ("slow".equalsIgnoreCase(System.getenv("VERSION"))) {
			System.out.println("slow version invoked");
			synchronized (this) {
				try {
					TimeUnit.SECONDS.sleep(5);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return getMessage();
			}
		}

		return getMessage();
	}
}
